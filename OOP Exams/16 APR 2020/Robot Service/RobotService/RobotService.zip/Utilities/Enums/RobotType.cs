﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.Utilities.Enums
{
    public enum RobotType 
    { 
      HouseholdRobot = 1,
      PetRobot = 2,
      WalkerRobot = 3
    }
        
        
   
}
