﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters.Common.Enums
{
    public enum CardType
    {
        MagicCard = 1,
        TrapCard = 2

    }
}
