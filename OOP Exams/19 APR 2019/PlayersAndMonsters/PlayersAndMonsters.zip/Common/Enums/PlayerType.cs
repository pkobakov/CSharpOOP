﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters.Common.Enums
{
    public enum PlayerType
    {
        Beginner = 1,
        Advanced = 2
    }
}
