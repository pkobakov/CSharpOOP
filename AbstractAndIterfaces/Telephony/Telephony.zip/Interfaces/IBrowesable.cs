﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Interfaces
{
    public interface IBrowesable
    {
        public string Browse(string url);
    }
}
